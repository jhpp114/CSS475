-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: vergil.u.washington.edu:6498
-- Generation Time: Mar 08, 2019 at 01:57 PM
-- Server version: 5.5.18
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dungeon`
--

-- --------------------------------------------------------

--
-- Table structure for table `CAMPAIGN`
--

CREATE TABLE `CAMPAIGN` (
  `Campaign_name` varchar(25) NOT NULL,
  `Cam_map_name` varchar(25) NOT NULL,
  `Cam_master` varchar(20) NOT NULL,
  `Cam_player` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CAMPAIGN`
--

INSERT INTO `CAMPAIGN` (`Campaign_name`, `Cam_map_name`, `Cam_master`, `Cam_player`) VALUES
('Test Camp1', 'Raising Sun', 'Park', 1),
('Test Camp2', 'Raising Sun', 'Park', 2),
('Test Camp3', 'Raising Sun', 'Haram', 1);

-- --------------------------------------------------------

--
-- Table structure for table `EPISODE`
--

CREATE TABLE `EPISODE` (
  `Episode_num` int(11) NOT NULL,
  `Campai_name` varchar(25) NOT NULL,
  `Episode_location` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EPISODE`
--

INSERT INTO `EPISODE` (`Episode_num`, `Campai_name`, `Episode_location`) VALUES
(1, 'Test Camp1', 'test interest'),
(2, 'Test Camp2', 'test interest');

-- --------------------------------------------------------

--
-- Table structure for table `EPISODE_MONSTER`
--

CREATE TABLE `EPISODE_MONSTER` (
  `Monster_id` int(11) NOT NULL,
  `Monster_name` varchar(25) NOT NULL,
  `Monster_level_epi` int(11) NOT NULL,
  `Drop_item` varchar(20) NOT NULL DEFAULT 'NONE',
  `Monster_epi` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EPISODE_MONSTER`
--

INSERT INTO `EPISODE_MONSTER` (`Monster_id`, `Monster_name`, `Monster_level_epi`, `Drop_item`, `Monster_epi`) VALUES
(1, 'weak undead', 10, 'bone', 2);

-- --------------------------------------------------------

--
-- Table structure for table `EPISODE_NPC`
--

CREATE TABLE `EPISODE_NPC` (
  `Npc_id` int(11) NOT NULL,
  `Epi_npc_name` varchar(15) NOT NULL DEFAULT 'NONE',
  `Epi_num_npc` int(11) NOT NULL,
  `Npc_level` int(11) NOT NULL,
  `Quest_reward` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EPISODE_NPC`
--

INSERT INTO `EPISODE_NPC` (`Npc_id`, `Epi_npc_name`, `Epi_num_npc`, `Npc_level`, `Quest_reward`) VALUES
(3, 'Test NPC2', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `INCLUDE_CAMP_CHARC`
--

CREATE TABLE `INCLUDE_CAMP_CHARC` (
  `Campai_name` varchar(25) NOT NULL,
  `Charc_name` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `INCLUDE_CAMP_MONSTER`
--

CREATE TABLE `INCLUDE_CAMP_MONSTER` (
  `Camp_name_mons` varchar(25) NOT NULL,
  `Monster_name_camp` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `INCLUDE_CAMP_MONSTER`
--

INSERT INTO `INCLUDE_CAMP_MONSTER` (`Camp_name_mons`, `Monster_name_camp`) VALUES
('Test Camp2', 'weak undead');

-- --------------------------------------------------------

--
-- Table structure for table `INCLUDE_CAMP_NPC`
--

CREATE TABLE `INCLUDE_CAMP_NPC` (
  `Camp_name` varchar(25) NOT NULL,
  `Npc_name` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `INCLUDE_CAMP_NPC`
--

INSERT INTO `INCLUDE_CAMP_NPC` (`Camp_name`, `Npc_name`) VALUES
('Test Camp2', 'Test NPC2');

-- --------------------------------------------------------

--
-- Table structure for table `ITEM`
--

CREATE TABLE `ITEM` (
  `Item_id` int(11) NOT NULL,
  `Item_name` varchar(25) NOT NULL,
  `Item_owner_character` varchar(15) NOT NULL,
  `Item_value` varchar(6) NOT NULL,
  `Item_count` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ITEM`
--

INSERT INTO `ITEM` (`Item_id`, `Item_name`, `Item_owner_character`, `Item_value`, `Item_count`) VALUES
(1, 'Css Book', 'Super Worrior', 'plat', 1);

-- --------------------------------------------------------

--
-- Table structure for table `MAP`
--

CREATE TABLE `MAP` (
  `Map_number` int(11) NOT NULL,
  `Map_name` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MAP`
--

INSERT INTO `MAP` (`Map_number`, `Map_name`) VALUES
(1, 'Raising Sun'),
(2, 'Victoria Island'),
(3, 'Sleep Wood');

-- --------------------------------------------------------

--
-- Table structure for table `MONSTER`
--

CREATE TABLE `MONSTER` (
  `Monster_name` varchar(25) NOT NULL,
  `Monster_level` int(11) NOT NULL,
  `Monster_type` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MONSTER`
--

INSERT INTO `MONSTER` (`Monster_name`, `Monster_level`, `Monster_type`) VALUES
('Animal1', 1, 'animal'),
('weak undead', 10, 'undead');

-- --------------------------------------------------------

--
-- Table structure for table `NON_PLAYER_CHARACTER`
--

CREATE TABLE `NON_PLAYER_CHARACTER` (
  `Npc_name` varchar(15) NOT NULL,
  `Npc_class` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NON_PLAYER_CHARACTER`
--

INSERT INTO `NON_PLAYER_CHARACTER` (`Npc_name`, `Npc_class`) VALUES
('Test NPC1', 'merchant'),
('Test NPC2', 'magician');

-- --------------------------------------------------------

--
-- Table structure for table `PCHARACTER`
--

CREATE TABLE `PCHARACTER` (
  `Character_name` varchar(15) NOT NULL,
  `Charac_player_id` int(11) NOT NULL,
  `Charac_level` int(11) NOT NULL,
  `Charac_passive_perception` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PCHARACTER`
--

INSERT INTO `PCHARACTER` (`Character_name`, `Charac_player_id`, `Charac_level`, `Charac_passive_perception`) VALUES
('Super Worrior', 4, 99, 99),
('Strong Pope', 1, 44, 44);

-- --------------------------------------------------------

--
-- Table structure for table `PLAYER`
--

CREATE TABLE `PLAYER` (
  `Player_id` int(11) NOT NULL,
  `Player_name` varchar(20) NOT NULL,
  `Player_phone` char(10) NOT NULL,
  `Player_email` varchar(30) DEFAULT NULL,
  `Player_join_date` date NOT NULL,
  `Player_leave_date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PLAYER`
--

INSERT INTO `PLAYER` (`Player_id`, `Player_name`, `Player_phone`, `Player_email`, `Player_join_date`, `Player_leave_date`) VALUES
(1, 'nemo', '2061231234', 'jhpp114@uw.edu', '2000-10-05', '0000-00-00'),
(2, 'Haram', '1231231234', 'ha@uw.edu', '2013-10-19', '0000-00-00'),
(3, 'Rider', '9879879876', 'rid@uw.edu', '2016-12-25', '0000-00-00'),
(4, 'Park', '2133215678', 'park@uw.edu', '1992-10-05', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `POINT_OF_INTEREST`
--

CREATE TABLE `POINT_OF_INTEREST` (
  `Location_num` int(11) NOT NULL,
  `Location_name` varchar(15) NOT NULL,
  `Map_location_name` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `POINT_OF_INTEREST`
--

INSERT INTO `POINT_OF_INTEREST` (`Location_num`, `Location_name`, `Map_location_name`) VALUES
(1, 'test interest', 'Victoria Island');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CAMPAIGN`
--
ALTER TABLE `CAMPAIGN`
  ADD PRIMARY KEY (`Campaign_name`),
  ADD KEY `Cam_map_name` (`Cam_map_name`),
  ADD KEY `Cam_player` (`Cam_player`);

--
-- Indexes for table `EPISODE`
--
ALTER TABLE `EPISODE`
  ADD PRIMARY KEY (`Episode_num`),
  ADD KEY `Campai_name` (`Campai_name`),
  ADD KEY `Episode_location` (`Episode_location`);

--
-- Indexes for table `EPISODE_MONSTER`
--
ALTER TABLE `EPISODE_MONSTER`
  ADD PRIMARY KEY (`Monster_id`),
  ADD KEY `Monster_name` (`Monster_name`),
  ADD KEY `Monster_epi` (`Monster_epi`);

--
-- Indexes for table `EPISODE_NPC`
--
ALTER TABLE `EPISODE_NPC`
  ADD PRIMARY KEY (`Npc_id`),
  ADD KEY `Epi_npc_name` (`Epi_npc_name`),
  ADD KEY `Epi_num_npc` (`Epi_num_npc`);

--
-- Indexes for table `INCLUDE_CAMP_CHARC`
--
ALTER TABLE `INCLUDE_CAMP_CHARC`
  ADD PRIMARY KEY (`Campai_name`,`Charc_name`),
  ADD KEY `Charc_name` (`Charc_name`);

--
-- Indexes for table `INCLUDE_CAMP_MONSTER`
--
ALTER TABLE `INCLUDE_CAMP_MONSTER`
  ADD PRIMARY KEY (`Camp_name_mons`,`Monster_name_camp`),
  ADD KEY `Monster_name_camp` (`Monster_name_camp`);

--
-- Indexes for table `INCLUDE_CAMP_NPC`
--
ALTER TABLE `INCLUDE_CAMP_NPC`
  ADD PRIMARY KEY (`Camp_name`,`Npc_name`),
  ADD KEY `Npc_name` (`Npc_name`);

--
-- Indexes for table `ITEM`
--
ALTER TABLE `ITEM`
  ADD PRIMARY KEY (`Item_id`),
  ADD KEY `Item_owner_character` (`Item_owner_character`);

--
-- Indexes for table `MAP`
--
ALTER TABLE `MAP`
  ADD PRIMARY KEY (`Map_name`);

--
-- Indexes for table `MONSTER`
--
ALTER TABLE `MONSTER`
  ADD PRIMARY KEY (`Monster_name`);

--
-- Indexes for table `NON_PLAYER_CHARACTER`
--
ALTER TABLE `NON_PLAYER_CHARACTER`
  ADD PRIMARY KEY (`Npc_name`);

--
-- Indexes for table `PCHARACTER`
--
ALTER TABLE `PCHARACTER`
  ADD PRIMARY KEY (`Character_name`),
  ADD KEY `Charac_player_id` (`Charac_player_id`);

--
-- Indexes for table `PLAYER`
--
ALTER TABLE `PLAYER`
  ADD PRIMARY KEY (`Player_id`);

--
-- Indexes for table `POINT_OF_INTEREST`
--
ALTER TABLE `POINT_OF_INTEREST`
  ADD PRIMARY KEY (`Location_num`),
  ADD UNIQUE KEY `Location_name` (`Location_name`),
  ADD KEY `Map_location_name` (`Map_location_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `EPISODE`
--
ALTER TABLE `EPISODE`
  MODIFY `Episode_num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `EPISODE_MONSTER`
--
ALTER TABLE `EPISODE_MONSTER`
  MODIFY `Monster_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `EPISODE_NPC`
--
ALTER TABLE `EPISODE_NPC`
  MODIFY `Npc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ITEM`
--
ALTER TABLE `ITEM`
  MODIFY `Item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `PLAYER`
--
ALTER TABLE `PLAYER`
  MODIFY `Player_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `POINT_OF_INTEREST`
--
ALTER TABLE `POINT_OF_INTEREST`
  MODIFY `Location_num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
