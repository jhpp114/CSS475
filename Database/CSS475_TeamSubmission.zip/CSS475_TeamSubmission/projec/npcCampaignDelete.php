<?php

$mysqli_connection = new MySQLi('vergil.u.washington.edu', 'root', '0505007pP', 'dungeon', 6498);
if($mysqli_connection->connect_error){
   echo "Not connected, error: ".$mysqli_connection->connect_error;
}

$Camp_name = $_POST["Camp_name"];
$Npc_name = $_POST["Npc_name"];

if (!empty($Camp_name)) {
  $sqlResult = "SELECT Camp_name FROM INCLUDE_CAMP_NPC";
  $result = $mysqli_connection->query($sqlResult);
  $fore1 = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Camp_name"] == $Camp_name) {
        $sql = "DELETE FROM INCLUDE_CAMP_NPC WHERE Camp_name = $Camp_name";
        $fore1 = TRUE;
        break;
      } else {
        $fore1 = FALSE;
      }
    }
  } else {
    $fore1 = FALSE;
  }
}
if (!$fore1) {
  header("refresh:3; url=npc.php");
  echo "Campaign Name Not Found";
  die();
}

if (!empty($Npc_name)) {
  $squlResult = "SELECT Npc_name FROM INCLUDE_CAMP_NPC";
  $result = $mysqli_connection->query($sqlResult);
  $fore = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Npc_name"] == $Npc_name) {
        $sql = "DELETE FROM INCLUDE_CAMP_NPC WHERE Npc_name = $Npc_name";
        $fore = TRUE;
        break;
      } else {
        $fore = FALSE;
      }
    }
  } else {
    $fore = FALSE;
  }
}

if (!$fore) {
  header("refresh:3; url=npc.php");
  echo "Npc Name Not Found";
  die();
}

header("refresh:2; url=npc.php");
if (!mysqli_query($mysqli_connection,$sql)) {
  echo 'Not Delete';
  echo "<br>";
} else {
  echo 'Delete Successfully';
  echo "<br>";
}

 ?>
