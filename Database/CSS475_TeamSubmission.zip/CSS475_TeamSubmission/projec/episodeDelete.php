<?php

$mysqli_connection = new MySQLi('vergil.u.washington.edu', 'root', '0505007pP', 'dungeon', 6498);
if($mysqli_connection->connect_error){
   echo "Not connected, error: ".$mysqli_connection->connect_error;
}

$Episode_num = $_POST["Episode_num"];
// $Campai_name = $_POST["Campai_name"];
// $Episode_location = $_POST["Episode_location"];

if (!empty($Episode_num)) {
  $sqlResult = "SELECT Monster_epi FROM EPISODE_MONSTER";
  $result = $mysqli_connection->query($sqlResult);
  $fore = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Monster_epi"] == $Episode_num) {
        $fore = FALSE;
        break;
      } else {
        $fore = TRUE;
      }
    }
  } else {
    $fore = TRUE;
  }
}

if (!$fore) {
  header("refresh:3; url=geo.php");
  echo "Delete Episode Monster First";
  die();
}

if (!empty($Episode_num)) {
  $sqlResult = "SELECT Epi_num_npc FROM EPISODE_NPC";
  $reulst = $mysqli_connection->query($sqlResult);
  $fore2 = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Epi_num_npc"] == $Episode_num) {
        $for2 = FALSE;
        break;
      } else {
        $fore2 = TRUE;
      }
    }
  } else {
    $fore2 = TRUE;
  }
}

if (!$fore2) {
  header("refresh:3; url=geo.php");
  echo "Delete Episode NPC First Before Delete Episode";
  die();
}

if (!empty($Episode_num)) {
  $sqlResult = "SELECT Episode_num FROM EPISODE";
  $result = $mysqli_connection->query($sqlResult);
  $fore1 = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Episode_num"] == $Episode_num) {
        $sql = "DELETE FROM EPISODE WHERE Episode_num = $Episode_num";
        $fore1 = TRUE;
        break;
      } else {
        $fore1 = FALSE;
      }
    }
  } else {
    $fore1 = FALSE;
  }
}

if (!$fore1) {
  header("refresh:3; url=geo.php");
  echo "Episode Number Does not Exist";
  die();
}

header("refresh:3; url=geo.php");
if (!mysqli_query($mysqli_connection,$sql)) {
  echo 'Not Delete';
  echo "<br>";
} else {
  echo "Delete Successfully";
  echo "<br>";
}

 ?>
