<?php

// connection
$mysqli_connection = new MySQLi('vergil.u.washington.edu', 'root', '0505007pP', 'dungeon', 6498);
if($mysqli_connection->connect_error){
   echo "Not connected, error: ".$mysqli_connection->connect_error;
}

$Npc_name = $_POST["Npc_name"];

// npc cannot remove until episode_npc removed
if (!empty($Npc_name)) {
  $sqlResult = "SELECT Epi_npc_name FROM EPISODE_NPC";
  $reuslt = $mysqli_connection->query($sqlResult);
  $fore = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Epi_npc_name"] == $Npc_name) {
        $fore = FALSE;
        break;
      } else {
        $fore = TRUE;
      }
    }
  } else {
    $fore = TRUE;
  }
}

if (!$fore) {
  header("refresh:3; url=npc.php");
  echo "Delete Episode NPC First Before Delete NPC";
  die();
}

if (!empty($Npc_name)) {
  $sqlResult = "SELECT Npc_name FROM NON_PLAYER_CHARACTER";
  $result = $mysqli_connection->query($sqlResult);
  $fore1 = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Npc_name"] == $Npc_name) {
        $sql = "DELETE FROM NON_PLAYER_CHARACTER WHERE Npc_name = $Npc_name";
        $fore1 = TRUE;
        break;
      } else {
        $fore1 = FALSE;
      }
    }
  } else {
    $fore1 = FALSE;
  }
}

if (!$fore1) {
  header("refresh:3; url=npc.php");
  echo "Npc Name is Not FOUND";
  die();
}

header("refresh:2; url=npc.php");
if (!mysqli_query($mysqli_connection,$sql)) {
  echo 'Not Delete';
  echo "<br>";
} else {
  echo "Delete Successfully";
  echo "<br>";
}

 ?>
