<?php

$mysqli_connection = new MySQLi('vergil.u.washington.edu', 'root', '0505007pP', 'dungeon', 6498);
if($mysqli_connection->connect_error){
   echo "Not connected, error: ".$mysqli_connection->connect_error;
}

$Npc_id = $_POST["Npc_id"];
$Epi_npc_name = $_POST["Epi_npc_name"];
$Epi_num_npc = $_POST["Epi_num_npc"];

if (!empty($Npc_id)) {
  $sqlResult = "SELECT Npc_id FROM EPISODE_NPC";
  $result = $mysqli_connection->query($sqlResult);
  $fore = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Npc_id"] == $Npc_id) {
        $sql = "DELETE FROM EPISODE_NPC WHERE Npc_id = $Npc_id";
        $fore = TRUE;
        break;
      } else {
        $fore = FALSE;
      }
    }
  } else {
    $fore = FALSE;
  }
}

if (!$fore) {
  header("refresh:3; url=npc.php");
  echo "NPC ID NOT FOUND";
  die();
}

// if (!empty($Epi_npc_name)) {
//   $sqlResult = "SELECT Epi_npc_name FROM ";
// }

header("refresh:3; url=npc.php");
if (!mysqli_query($mysqli_connection,$sql)) {
  echo 'Not Delete';
  echo "<br>";
} else {
  echo "Delete Successfully";
  echo "<br>";
}

 ?>
