<?php

$mysqli_connection = new MySQLi('vergil.u.washington.edu', 'root', '0505007pP', 'dungeon', 6498);
if($mysqli_connection->connect_error){
   echo "Not connected, error: ".$mysqli_connection->connect_error;
}

$Camp_name_mons = $_POST["Camp_name_mons"];
// $Monster_name_camp = $_POST["Monster_name_camp"];

if (!empty($Camp_name_mons)) {
  $sqlResult = "SELECT Camp_name_mons FROM INCLUDE_CAMP_MONSTER";
  $result = $mysqli_connection->query($sqlResult);
  $fore = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Camp_name_mons"] == $Camp_name_mons) {
        $sql = "DELETE FROM INCLUDE_CAMP_MONSTER WHERE Camp_name_mons = $Camp_name_mons";
        $fore = TRUE;
        break;
      } else {
        $fore = FALSE;
      }
    }
  } else {
    $fore = FALSE;
  }
}
if (!$fore) {
  header("refresh:3; url=monster.php");
  echo "Campaign Name is NOT FOUND";
  die();
}

header("refresh:2; url=monster.php");
if (!mysqli_query($mysqli_connection,$sql)) {
  echo 'Not Delete';
  echo "<br>";
} else {
  echo 'Delete Successfully';
  echo "<br>";
}



 ?>
