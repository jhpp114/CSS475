<?php

$mysqli_connection = new MySQLi('vergil.u.washington.edu', 'root', '0505007pP', 'dungeon', 6498);
if($mysqli_connection->connect_error){
   echo "Not connected, error: ".$mysqli_connection->connect_error;
}

$Monster_id = $_POST["Monster_id"];
// $Monster_name = $_POST["Monster_name"];
// $Monster_epi = $_POST["Monster_epi"];

if (!empty($Monster_id)) {
  $sqlResult = "SELECT Monster_id FROM EPISODE_MONSTER";
  $result = $mysqli_connection->query($sqlResult);
  $fore = TRUE;
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      if ($row["Monster_id"] == $Monster_id) {
        $sql = "DELETE FROM EPISODE_MONSTER WHERE Monster_id = $Monster_id";
        $fore = TRUE;
        break;
      } else {
        $fore = FALSE;
      }
    }
  } else {
    $fore = FALSE;
  }
}

if (!$fore) {
  header("refresh:3; url=monster.php");
  echo "Monster ID NOT FOUND";
  die();
}

header("refresh:2; url=monster.php");
if (!mysqli_query($mysqli_connection,$sql)) {
  echo 'Not Delete';
  echo "<br>";
} else {
  echo 'Delete Successfully';
  echo "<br>";
}

 ?>
